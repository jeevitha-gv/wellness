<?php
// Database connection info
$dbDetails = array(
    'host' => 'localhost',
    'user' => 'root',
    'pass' => 'Admin1234#@',
    'db'   => 'datalake'
);

// DB table to use
$table = 'records';

// Table's primary key
$primaryKey = 'id';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database. 
// The `dt` parameter represents the DataTables column identifier.
$columns = array(
    array( 'db' => 'id', 'dt' => 0 ),
    array( 'db' => 'company',  'dt' => 1 ),
    array( 'db' => 'parent_company',      'dt' => 2 ),
    array( 'db' => 'penalty_amount',     'dt' => 3 ),
    array( 'db' => 'penalty_year',    'dt' => 4 ),
    array( 'db' => 'penalty_date',    'dt' => 5 ),
    array( 'db' => 'primary_offense',    'dt' => 6 ),
    array( 'db' => 'level_of_government',    'dt' => 7 ),
    array( 'db' => 'agency',    'dt' => 8 ),
    
);

// Include SQL query processing class
require( 'ssp.class.php' );

// Output data as json format
echo json_encode(
    SSP::simple( $_GET, $dbDetails, $table, $primaryKey, $columns )
);